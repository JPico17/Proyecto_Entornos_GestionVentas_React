package uis.entornos.backend_nosql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendNosqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
