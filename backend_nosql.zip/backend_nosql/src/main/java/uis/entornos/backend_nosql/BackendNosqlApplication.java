package uis.entornos.backend_nosql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendNosqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendNosqlApplication.class, args);
	}

}
