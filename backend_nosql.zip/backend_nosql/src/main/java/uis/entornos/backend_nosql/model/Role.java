package uis.entornos.backend_nosql.model;

public enum Role {
    ADMIN,
    EMPLOYEE
}
